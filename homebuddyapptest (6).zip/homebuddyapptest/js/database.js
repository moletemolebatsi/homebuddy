// create database
	var db = openDatabase('homebuddyappdb', '1.0', 'Test DB', 2 * 1024 * 1024); 
    
	// insert database into database
	db.transaction(function (tx) { 
		tx.executeSql('CREATE TABLE IF NOT EXISTS users (email, password, name, address)'); 
		tx.executeSql('INSERT INTO users (username, password) VALUES ("test@test.com", "admin123")'); 		
	});
		 
	// add 'type of service' checkboxes from database
	var msg = "";	
	
	$('.cleaning-products-button-wrap').click(function(){
		
		$(this).find('span').each(function(){
			console.log('test');
			$(this).toggleClass('active');	
		});
	});