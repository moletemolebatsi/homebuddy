// Initialize your app
var myApp = new Framework7({
	swipePanel: 'left',
	swipeBackPage: false,
	material: true
});

// Export selectors engine
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});

var db = openDatabase('homebuddyappdb', '1.0', 'Test DB', 2 * 1024 * 1024); 
    
	// insert database into database
	db.transaction(function (tx) { 
		tx.executeSql('CREATE TABLE IF NOT EXISTS userst (email, password, name, address)');  		
	});
	
	var hidebtn = 'no';
	db.transaction(function (tx) { 
		tx.executeSql('select * from userst', [], function(tx, result){
				if(result.rows.length > 0){
					$('#toolbarregister').hide();
					hidebtn = 'yes';
				}
			});  		
	});
	
if(hidebtn == 'yes'){
	

}
	
	// add 'type of service' checkboxes from database
	var msg = "";	
	
	$('.cleaning-products-button-wrap').click(function(){
		
		$(this).find('span').each(function(){
			console.log('test');
			$(this).toggleClass('active');	
		});
	});

$('#registerbutton').click(function(){
		
		$('.registererrors').html('');
		
		var data = {
			'action': 'register',
			'registername': $('#registername').val(),
			'registeremail': $('#registeremail').val(),
			'registeraddress': $('#registeraddress').val(),
			'registerpassword': $('#registerpassword').val(),
			'registerconfirmpassword': $('#registerconfirmpassword').val()
		};
		
		var errors = false;
		
		if($('#registername').val() == ''){
			errors = true;
			$('.registernameerror').html('name cannot be empty');
		}
		
		if($('#registeremail').val() == ''){
			errors = true;
			$('.registeremailerror').html('email cannot be empty');
		}
		
		if($('#registeraddress').val() == ''){
			errors = true;
			$('.registeraddresserror').html('address cannot be empty');
		}
		
		if($('#registerpassword').val() == ''){
			errors = true;
			$('.registerpassworderror').html('password cannot be empty');
		}
		
		if($('#registerpassword').val() != $('#registerconfirmpassword').val()){
			errors = true;
			$('.registerconfirmpassworderror').html('confirm password is incorrect');
		}
		
		if(!errors){
			$.ajax({
				method: "POST",
				url: "http://google.com",
				data: data,
				error: function(jqXHR) { 
					if(jqXHR.status==0) {
						$('#snackbar').html("fail to connect, please check your connection settings");			
						$('#snackbar').addClass('show');
					}
				},
				success: function() {
						
				}
			}).done(function(response){
				
				db.transaction(function (tx) { 
				tx.executeSql('INSERT INTO userst (email, password, name, address) VALUES ("test@test.com", "admin123","test@test.com", "admin123")'); 		
	});
	
					
				$('#snackbar').html('registration successful');			
				$('#snackbar').addClass('show');
			
				setTimeout(function(){
					 $('#snackbar').removeClass('show');
				}, 1500);
				
	$('.close-popup')[0].click();
	$('.close-login-screen')[0].click();
	$('#toolbarregister').hide();
	
			});
		}	
	});
	
	$('#registerform input').focus(function(){
		$('#snackbar').removeClass('show');
	});
	
	$('#snackbar').click(function(){
		$('#snackbar').removeClass('show');
	});
	
$$(document).on('pageInit', function (e) {	
	
	var calendarModal = myApp.calendar({
			input: '#onceoffdate',
			openIn: 'customModal',
			header: true,
			footer: true,
			weekHeader: true,
			dateFormat: 'MM dd yyyy'
		});	
		
	$(".swipebox").swipebox();
	$(".videocontainer").fitVids();
	var i = 0;
	$("#loadmore").click(function(){
		i++;
		if(i<5) {
			var html = '';
			html += '<div class="card post-card"><div class="card-header"><div class="post-avatar"><img src="images/photos/avatar.jpg" width="34" height="34"></div><div class="post-name">John Doe</div><div class="post-date">Monday at 2:15 PM</div></div><div class="card-content"><div class="card-content-inner"><h4 class="title-post"><a href="single.html">The eye should learn to listen before it looks.</a></h4><img src="images/photos/5.jpg" width="100%" class="img"><p>What a nice photo i took yesterday! Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin et augue nec ex facilisis pulvinar.</p><p class="color-gray infos">Likes: 112  -  Comments: 43</p></div></div><div class="card-footer no-border"><a href="#" class="link">Like</a><a href="#" class="link">Comment</a><a href="#" class="link">Share</a></div></div>';
			$('#blog-page').append(html);
			
		}else{
			$("#loadmore").hide();
		}
	});
	
	
	
	$('.howmanytimes input[type=checkbox]').change(function(){	
		$('.howmanytimes input[type=text]').hide();
		$('.howmanytimes input[type=checkbox]').attr('checked', false);
		$(this).parent().next().toggle();
		$(this).attr('checked', true);
	});
	
	$('#weekly').change(function(){
		$('.weeklyselect')[0].click();
	});
	
	$('#monthly').change(function(){
		$('.monthlyselect')[0].click();
	});
	
	$('.typeofservicesinfo').click(function(){
		$('#normaldialog').dialog();
	});
	
	$('.typeofservicelist input[type=checkbox]').change(function(){
		var chk = $(this);
		$('.typeofservicelist input[type=checkbox]').each(function(){
			$(this).next().removeClass('checked');
		});
		
		chk.next().addClass('checked');
	});
	
	$('#onceoffchk').change(function(){
		$('#onceoffdate')[0].click();
	});
	
	$('#normal').change(function(){
		$('#normalmodal').toggle();
	});
	
	$('.closenormal').click(function(){
		$('#normalmodal').hide();
	});
	
	$('#onceoffspring').change(function(){
		$('#onceoffspringmodal').toggle();
	});
	
	$('.closeonceoffspring').click(function(){
		$('#onceoffspringmodal').hide();
	});
	
	$('#extra').change(function(){
		$('#extramodal').toggle();
	});
	
	$('.closeextra').click(function(){
		$('#extramodal').hide();
	});
	
	$('#full').change(function(){
		$('#fullmodal').toggle();
	});
	
	$('.closefull').click(function(){
		$('#fullmodal').hide();
	});
	
	$('.maid-link').click(function(){
		
	});
	
	db.transaction(function (tx) { 
		tx.executeSql('select * from userst', [], function(tx, result){
				if(result.rows.length > 0){
					$('#toolbarregister').hide();
					hidebtn = 'yes';
				}
			});  		
	});
	
});


