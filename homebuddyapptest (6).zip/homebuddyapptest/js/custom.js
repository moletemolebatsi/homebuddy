// defocus register button on error
$('#registerform input').focus(function(){
	$('#registerbutton').html('register now');
});

